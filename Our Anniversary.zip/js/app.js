/* Anniversary site: shared behaviour + one small module per page. */
(function () {
  'use strict';
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var esc = function (t) { return String(t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var HEART = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/></svg>';

  /* ---------- storage ---------- */
  var LS = {
    get: function (k, d) { try { var v = localStorage.getItem('ann:' + k); return v == null ? d : JSON.parse(v); } catch (e) { return d; } },
    set: function (k, v) { try { localStorage.setItem('ann:' + k, JSON.stringify(v)); } catch (e) {} }
  };
  /* uploaded photos and songs live in IndexedDB (files, not links) */
  var IDB = {
    db: null,
    open: function () {
      if (IDB.db) return Promise.resolve(IDB.db);
      return new Promise(function (res, rej) {
        try {
          var r = indexedDB.open('ann-files', 1);
          r.onupgradeneeded = function () { r.result.createObjectStore('files', { keyPath: 'id', autoIncrement: true }); };
          r.onsuccess = function () { IDB.db = r.result; res(r.result); };
          r.onerror = function () { rej(r.error); };
        } catch (e) { rej(e); }
      });
    },
    tx: function (mode, fn) {
      return IDB.open().then(function (db) {
        return new Promise(function (res, rej) {
          var t = db.transaction('files', mode), s = t.objectStore('files'), out = fn(s);
          t.oncomplete = function () { res(out && out.result); };
          t.onerror = function () { rej(t.error); };
        });
      });
    },
    add: function (rec) { return IDB.tx('readwrite', function (s) { return s.add(rec); }); },
    all: function (kind) { return IDB.tx('readonly', function (s) { return s.getAll(); }).then(function (a) { return (a || []).filter(function (x) { return x.kind === kind; }); }).catch(function () { return []; }); },
    del: function (id) { return IDB.tx('readwrite', function (s) { return s.delete(id); }); }
  };

  /* ---------- content defaults (all editable on the Customize page) ---------- */
  var DEF = {
    a: 'Alex', b: 'Sam', date: '2024-10-26', accent: 'rose',
    story: 'Before we met\nSomewhere out there, two ordinary lives were quietly lining up. A plain day, a crowded room, a message sent on a whim, and nothing would be the same again.\n\nThe first hello\n{a} said hello and {b} smiled, and the whole world made a little more room. It felt small then. It feels enormous now.\n\nThe moment we knew\nThere was no thunder, only a calm certainty. Sitting beside {b}, {a} understood that home is not a place, it is a person.\n\nOur little rituals\nMorning tea, silly nicknames, songs in the car, a hand reached out without looking. These tiny habits became the walls of our favourite place.\n\nToday and always\nThrough busy weeks and quiet evenings, we keep choosing each other. Happy anniversary, {b}. The best chapters are still unwritten.',
    timeline: 'Day one | The day we met | A simple hello that quietly changed both our lives.\nThe first week | Messages that never ended | We ran out of sleep long before we ran out of things to say.\nThe first month | Our first real date | Nervous laughter, shared dessert, and a walk home the long way.\nThe first trip | Adventures together | Wrong turns, right company, and photos we still smile at.\nThe hard days | Holding on | We learned that love is also patience, honesty and staying.\nA promise | Choosing each other | No grand speech, just a quiet yes that meant forever.\nThis anniversary | Still falling | Every year with you is my favourite chapter so far.',
    letter: 'My dearest {b},\n\nAnother year has passed, and somehow I still get butterflies when I think of you. Thank you for the laughter, the patience, the quiet mornings and the loud adventures.\n\nYou have taught me that love is not only grand moments. It is the cup of tea made just right, the message that says "reached home safe", the way you stay when things are hard.\n\nI do not know what the future holds, but I know I want to meet it with you. Today, tomorrow and every anniversary after.\n\nHappy anniversary, my love.',
    sign: 'Forever yours, {a}',
    reasons: 'Your laugh makes any room brighter.\nYou listen like it is the only thing that matters.\nYou make ordinary days feel like holidays.\nYour kindness shows up in the smallest things.\nYou believe in me when I forget how.\nThe way you hum when you think nobody hears.\nYou make home feel like a person.\nYou are brave in ways you never brag about.\nYour hand fits mine as if it was made to.\nYou turn arguments into understanding.\nYou remember the little things that matter to me.\nSimply because it is you.'
  };
  var CAPTIONS = ['Our first spring', 'Soft little moments', 'Tea and sunsets', 'Golden hours', 'Wild flowers, wild hearts', 'Forever starts here'];
  var COUPONS = [['Breakfast in bed', 'Pancakes, flowers, zero chores'], ['A long walk, no phones', 'Just us and a sunset'], ['Movie night, your pick', 'I will not complain once'], ['One big, long hug', 'Valid any time, no expiry'], ['A handwritten love note', 'Hidden somewhere for you to find'], ['Dinner cooked by me', 'Menu chosen by you'], ['Dance in the kitchen', 'Our song, one step too many'], ['A wish granted', 'Within reason, and with a smile']];
  var PROMISES = ['I will listen first and speak second.', 'I will make you laugh every single day.', 'I will hold your hand in the hard moments.', 'I will celebrate your wins louder than my own.', 'I will keep choosing you, on easy days and difficult ones.', 'I will grow old with you, and still dance in the kitchen.'];
  var PAGES = [
    ['index.html', 'Home', 'Our days together'],
    ['story.html', 'Our Story', 'How it began'],
    ['timeline.html', 'Timeline', 'Moments that mattered'],
    ['gallery.html', 'Gallery', 'Photos and keepsakes'],
    ['letter.html', 'Love Letter', 'Words from the heart'],
    ['reasons.html', 'Reasons', 'Why I love you'],
    ['music.html', 'Our Songs', 'The soundtrack'],
    ['wishes.html', 'Wishes', 'Make a wish, read my promises'],
    ['surprise.html', 'Surprise', 'Love coupons and a secret'],
    ['qr.html', 'QR and Link', 'Heart QR, colours, short link'],
    ['customize.html', 'Make it yours', 'Names, date, photos, songs']
  ];
  var BUILTIN = [
    { title: 'Forever Yours', note: 'Music box in C', src: 'audio/forever-yours.mp3' },
    { title: 'Moonlit Waltz', note: 'Slow waltz in G', src: 'audio/moonlit-waltz.mp3' },
    { title: 'Golden Hour', note: 'Gentle chords in F', src: 'audio/golden-hour.mp3' }
  ];

  var C = Object.assign({}, DEF, LS.get('cfg', {}));
  var fmt = function (t) { return esc(t).replace(/\{a\}/g, esc(C.a)).replace(/\{b\}/g, esc(C.b)); };
  var fmtRaw = function (t) { return String(t).replace(/\{a\}/g, C.a).replace(/\{b\}/g, C.b); };
  var parseDate = function (s) { var p = String(s).split('-'); return new Date(+p[0], (+p[1] || 1) - 1, +p[2] || 1); };
  var pad = function (n) { return n < 10 ? '0' + n : '' + n; };
  var fmtTime = function (t) { if (!isFinite(t)) return '0:00'; t = Math.floor(t); return Math.floor(t / 60) + ':' + pad(t % 60); };
  var toastTimer;
  function toast(msg) {
    var t = $('.toast'); if (!t) { t = document.createElement('div'); t.className = 'toast'; t.setAttribute('role', 'status'); document.body.appendChild(t); }
    t.textContent = msg; t.classList.add('on'); clearTimeout(toastTimer); toastTimer = setTimeout(function () { t.classList.remove('on'); }, 2200);
  }
  function copy(text, input) {
    var ok = function () { toast('Copied'); };
    var fallback = function () { try { if (input) { input.focus(); input.select(); } document.execCommand('copy'); ok(); } catch (e) { toast('Press and hold the text to copy'); } };
    try { navigator.clipboard.writeText(text).then(ok, fallback); } catch (e) { fallback(); }
  }
  function burst(x, y, n) {
    var cols = ['#d4607b', '#8b2a48', '#f0a3b3', '#b98a5c', '#e8788f'];
    for (var i = 0; i < (n || 22); i++) {
      var h = document.createElement('i'); h.className = 'burst';
      var a = Math.random() * Math.PI * 2, d = 60 + Math.random() * 170;
      h.style.left = x - 11 + 'px'; h.style.top = y - 11 + 'px'; h.style.background = cols[i % cols.length];
      h.style.setProperty('--dx', Math.cos(a) * d + 'px'); h.style.setProperty('--dy', Math.sin(a) * d - 40 + 'px'); h.style.setProperty('--r', (Math.random() * 120 - 60) + 'deg');
      document.body.appendChild(h); setTimeout(function (el) { el.remove(); }.bind(null, h), 1700);
    }
  }
  window.ANN = { burst: burst, toast: toast };

  /* ---------- shell: backgrounds, top bar, menu, floating hearts ---------- */
  var main = $('main.sheet');
  var pageKey = main ? main.getAttribute('data-page') : '';
  document.documentElement.setAttribute('data-accent', C.accent || 'rose');
  document.title = document.title.replace('{names}', fmtRaw(C.a) + ' & ' + fmtRaw(C.b));

  function buildShell() {
    var bg = main.getAttribute('data-bg') || 'bow';
    var wide = document.createElement('div'); wide.className = 'bgwide'; wide.setAttribute('data-bg', bg);
    var fix = document.createElement('div'); fix.className = 'bgfix'; fix.setAttribute('data-bg', bg);
    document.body.insertBefore(fix, document.body.firstChild); document.body.insertBefore(wide, document.body.firstChild);

    var bar = document.createElement('header'); bar.className = 'topbar';
    bar.innerHTML = '<a class="brand" href="index.html">' + HEART + '<span>' + esc(C.a) + ' &amp; ' + esc(C.b) + '</span></a>' +
      '<button class="iconbtn" id="menuBtn" aria-label="Open menu" aria-expanded="false"><svg viewBox="0 0 24 24"><path d="M4 7h16M4 12h16M4 17h16"/></svg></button>';
    document.body.appendChild(bar);

    var dr = document.createElement('div'); dr.className = 'drawer'; dr.id = 'drawer'; dr.setAttribute('role', 'dialog'); dr.setAttribute('aria-label', 'Menu');
    var items = PAGES.map(function (p) { return '<li><a href="' + p[0] + '"' + (p[0].indexOf(pageKey === 'home' ? 'index' : pageKey) === 0 ? ' aria-current="page"' : '') + '><b>' + p[1] + '</b><span>' + p[2] + '</span></a></li>'; }).join('');
    var sw = [['rose', '#d4607b', 'Rose'], ['wine', '#a8324f', 'Wine'], ['blush', '#e08a9a', 'Blush'], ['lilac', '#a77bb8', 'Lilac'], ['sage', '#6f9a7f', 'Sage'], ['gold', '#c79556', 'Gold']]
      .map(function (s) { return '<button class="sw" data-acc="' + s[0] + '" style="background:' + s[1] + '" aria-label="' + s[2] + ' colour" aria-pressed="' + (C.accent === s[0]) + '"></button>'; }).join('');
    dr.innerHTML = '<div class="scrim" data-close></div><div class="sheetmenu"><div class="row"><span class="script" style="font-size:2rem">Menu</span><button class="iconbtn" data-close aria-label="Close menu"><svg viewBox="0 0 24 24"><path d="M6 6l12 12M18 6L6 18"/></svg></button></div><ul class="menu">' + items + '</ul><div><p class="lab" style="margin-bottom:8px">Colour of the site</p><div class="swatches">' + sw + '</div></div></div>';
    document.body.appendChild(dr);
    function setOpen(o) { dr.classList.toggle('open', o); $('#menuBtn').setAttribute('aria-expanded', o); }
    $('#menuBtn').addEventListener('click', function () { setOpen(true); });
    dr.addEventListener('click', function (e) {
      if (e.target.closest('[data-close]')) setOpen(false);
      var s = e.target.closest('.sw'); if (s) {
        C.accent = s.getAttribute('data-acc'); var cur = LS.get('cfg', {}); cur.accent = C.accent; LS.set('cfg', cur);
        document.documentElement.setAttribute('data-accent', C.accent);
        $$('.sw', dr).forEach(function (b) { b.setAttribute('aria-pressed', b === s); });
        window.dispatchEvent(new Event('accentchange'));
      }
    });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') setOpen(false); });

    var fl = document.createElement('div'); fl.className = 'floaty'; fl.setAttribute('aria-hidden', 'true');
    var cols = ['#e8788f', '#f2a7b5', '#d4607b', '#f7c6cf'];
    for (var i = 0; i < 9; i++) {
      var h = document.createElement('i'); h.textContent = '♥';
      h.style.cssText = 'left:' + (Math.random() * 100) + '%;--s:' + (12 + Math.random() * 20) + 'px;--c:' + cols[i % 4] + ';--d:' + (11 + Math.random() * 12) + 's;--w:-' + (Math.random() * 20) + 's;--x:' + (Math.random() * 80 - 40) + 'px';
      fl.appendChild(h);
    }
    document.body.appendChild(fl);
  }

  /* ---------- music: one audio element per page, state carried through localStorage ---------- */
  var Player = (function () {
    var au = new Audio(); au.preload = 'metadata';
    var list = BUILTIN.slice(), st = LS.get('player', { i: 0, t: 0, playing: false }), listeners = [], ready = false, urls = [];
    function save() { LS.set('player', { i: st.i, t: au.currentTime || 0, playing: !au.paused }); }
    function emit() { listeners.forEach(function (f) { f(); }); }
    function load(i, autoplay, at) {
      st.i = (i + list.length) % list.length; au.src = list[st.i].src;
      var seek = function () { if (at) { try { au.currentTime = at; } catch (e) {} } au.removeEventListener('loadedmetadata', seek); };
      au.addEventListener('loadedmetadata', seek);
      if (autoplay) play(); emit();
    }
    function play() {
      var p = au.play();
      if (p && p.catch) p.catch(function () {
        var once = function () { au.play().catch(function () {}); document.removeEventListener('pointerdown', once); };
        document.addEventListener('pointerdown', once);
      });
    }
    au.addEventListener('ended', function () { load(st.i + 1, true, 0); });
    ['play', 'pause', 'timeupdate'].forEach(function (ev) { au.addEventListener(ev, function () { if (ev !== 'timeupdate' || Math.floor(au.currentTime) % 2 === 0) save(); emit(); }); });
    window.addEventListener('pagehide', save);
    return {
      list: function () { return list; }, cur: function () { return st.i; }, audio: au, isPlaying: function () { return !au.paused; },
      on: function (f) { listeners.push(f); },
      toggle: function () { if (au.paused) play(); else au.pause(); },
      next: function () { load(st.i + 1, true, 0); }, prev: function () { load(st.i - 1, true, 0); },
      pick: function (i) { if (i === st.i && au.src) { Player.toggle(); } else load(i, true, 0); },
      seek: function (f) { if (isFinite(au.duration)) au.currentTime = f * au.duration; },
      init: function () {
        return IDB.all('song').then(function (songs) {
          songs.forEach(function (s) { var u = URL.createObjectURL(s.blob); urls.push(u); list.push({ title: s.name, note: 'Your own song', src: u, id: s.id }); });
          ready = true; var i = Math.min(st.i || 0, list.length - 1);
          load(i, !!st.playing, st.t || 0);
        });
      }
    };
  })();
  window.ANN.player = Player;

  function buildMini() {
    if (pageKey === 'music') return;
    var m = document.createElement('div'); m.className = 'mini';
    m.innerHTML = '<button class="iconbtn go" id="mpPlay" aria-label="Play music"></button><div class="t"><small>Now playing</small><b id="mpTitle">Our song</b></div><button class="iconbtn" id="mpNext" aria-label="Next song"><svg viewBox="0 0 24 24"><path d="M6 5l9 7-9 7zM18 5v14"/></svg></button>';
    document.body.appendChild(m);
    var PLAY = '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5l11 7-11 7z"/></svg>', PAUSE = '<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M7 5h4v14H7zM13 5h4v14h-4z"/></svg>';
    function sync() { var p = Player.isPlaying(); $('#mpPlay').innerHTML = p ? PAUSE : PLAY; $('#mpPlay').setAttribute('aria-label', p ? 'Pause music' : 'Play music'); var t = Player.list()[Player.cur()]; if (t) $('#mpTitle').textContent = t.title; }
    $('#mpPlay').addEventListener('click', function () { Player.toggle(); }); $('#mpNext').addEventListener('click', function () { Player.next(); });
    Player.on(sync); sync();
  }

  /* ---------- fill the simple name/date placeholders ---------- */
  function fillBasics() {
    $$('[data-a]').forEach(function (e) { e.textContent = C.a; });
    $$('[data-b]').forEach(function (e) { e.textContent = C.b; });
    var d = parseDate(C.date);
    $$('[data-date-long]').forEach(function (e) { e.textContent = d.toLocaleDateString(undefined, { day: 'numeric', month: 'long', year: 'numeric' }); });
  }
  function yearsBetween(d, now) {
    var y = now.getFullYear() - d.getFullYear(), m = now.getMonth() - d.getMonth();
    if (m < 0 || (m === 0 && now.getDate() < d.getDate())) y--; return Math.max(0, y);
  }
  var ORD = ['zero', 'first', 'second', 'third', 'fourth', 'fifth', 'sixth', 'seventh', 'eighth', 'ninth', 'tenth'];
  function nth(n) { if (ORD[n]) return ORD[n]; var s = ['th', 'st', 'nd', 'rd'], v = n % 100; return n + (s[(v - 20) % 10] || s[v] || s[0]); }

  /* ---------- pages ---------- */
  var Pages = {};

  Pages.home = function () {
    var d = parseDate(C.date), now = new Date(), yrs = yearsBetween(d, now);
    var next = new Date(now.getFullYear(), d.getMonth(), d.getDate()); if (next < new Date(now.getFullYear(), now.getMonth(), now.getDate())) next = new Date(now.getFullYear() + 1, d.getMonth(), d.getDate());
    var days = Math.round((next - new Date(now.getFullYear(), now.getMonth(), now.getDate())) / 864e5), upcoming = yearsBetween(d, next) + 0;
    var nyr = next.getFullYear() - d.getFullYear();
    $('#years').textContent = yrs > 0 ? 'Celebrating ' + yrs + (yrs === 1 ? ' year' : ' years') + ' together' : 'Celebrating our first year';
    $('#nextBig').textContent = days === 0 ? 'Today' : days;
    $('#nextTxt').innerHTML = days === 0 ? 'It is our anniversary. Happy ' + nth(nyr) + ' anniversary!' : (days === 1 ? 'day' : 'days') + ' to our ' + nth(nyr) + ' anniversary';
    function tick() {
      var diff = Math.max(0, Date.now() - d.getTime()) / 1000;
      var parts = [['days', Math.floor(diff / 86400)], ['hours', Math.floor(diff / 3600) % 24], ['mins', Math.floor(diff / 60) % 60], ['secs', Math.floor(diff) % 60]];
      $('#counter').innerHTML = parts.map(function (p) { return '<div><b>' + p[1] + '</b><span>' + p[0] + '</span></div>'; }).join('');
    }
    tick(); setInterval(tick, 1000);
    $('#tiles').innerHTML = PAGES.slice(1).map(function (p) { return '<a class="tile" href="' + p[0] + '">' + HEART + '<b>' + p[1] + '</b><span>' + p[2] + '</span></a>'; }).join('');
    $('#playBtn').addEventListener('click', function (e) { Player.toggle(); burst(e.clientX, e.clientY, 14); });
    var syncBtn = function () { $('#playBtn').textContent = Player.isPlaying() ? 'Pause our song' : 'Play our song'; }; Player.on(syncBtn); syncBtn();
    if (!LS.get('cfg', null) || !LS.get('cfg', {}).a) { var hint = $('#setup'); if (hint) hint.hidden = false; }
    $('#confettiBtn').addEventListener('click', function () { for (var i = 0; i < 6; i++) setTimeout(function () { burst(innerWidth * (0.2 + Math.random() * 0.6), innerHeight * (0.25 + Math.random() * 0.3), 18); }, i * 160); });
  };

  Pages.story = function () {
    var blocks = C.story.split(/\n\s*\n/).filter(function (b) { return b.trim(); });
    $('#chapters').innerHTML = blocks.map(function (b, i) {
      var lines = b.trim().split('\n'), title = lines.shift();
      return '<article class="chapter panel rise" style="animation-delay:' + i * 0.08 + 's"><span class="n">' + (i + 1) + '</span><h3>' + fmt(title) + '</h3><p>' + fmt(lines.join(' ')) + '</p></article>';
    }).join('');
  };

  Pages.timeline = function () {
    var rows = C.timeline.split('\n').filter(function (l) { return l.trim(); });
    $('#tl').innerHTML = rows.map(function (l, i) {
      var p = l.split('|').map(function (x) { return x.trim(); });
      return '<li class="panel tight rise" style="animation-delay:' + i * 0.07 + 's"><div class="when">' + fmt(p[0] || '') + '</div><h3>' + fmt(p[1] || '') + '</h3><p>' + fmt(p[2] || '') + '</p></li>';
    }).join('');
  };

  Pages.gallery = function () {
    var items = [];
    for (var i = 1; i <= 6; i++) items.push({ src: 'img/memory-' + i + '.jpg', cap: CAPTIONS[i - 1] });
    var urls = [];
    IDB.all('photo').then(function (ph) {
      var mine = ph.map(function (p) { var u = URL.createObjectURL(p.blob); urls.push(u); return { src: u, cap: p.name, id: p.id }; });
      render(mine.concat(items));
    });
    function render(all) {
      $('#gal').innerHTML = all.map(function (it, i) {
        return '<figure data-i="' + i + '"><img src="' + it.src + '" alt="' + esc(it.cap) + '" loading="lazy"><figcaption>' + esc(it.cap) + '</figcaption></figure>';
      }).join('');
      var cur = 0, lb = $('#lb'), show = function (i) { cur = (i + all.length) % all.length; $('#lbImg').src = all[cur].src; $('#lbImg').alt = all[cur].cap; $('#lbCap').textContent = all[cur].cap; lb.classList.add('open'); };
      $('#gal').onclick = function (e) { var f = e.target.closest('figure'); if (f) show(+f.getAttribute('data-i')); };
      $('#lbPrev').onclick = function () { show(cur - 1); }; $('#lbNext').onclick = function () { show(cur + 1); };
      $('#lbClose').onclick = function () { lb.classList.remove('open'); };
      lb.onclick = function (e) { if (e.target === lb) lb.classList.remove('open'); };
      document.onkeydown = function (e) { if (!lb.classList.contains('open')) return; if (e.key === 'Escape') lb.classList.remove('open'); if (e.key === 'ArrowRight') show(cur + 1); if (e.key === 'ArrowLeft') show(cur - 1); };
    }
    $('#addPhotos').addEventListener('change', function (e) {
      var files = Array.prototype.slice.call(e.target.files || []); if (!files.length) return;
      Promise.all(files.map(function (f) { return IDB.add({ kind: 'photo', name: f.name.replace(/\.[^.]+$/, ''), blob: f }); })).then(function () { toast(files.length + ' photo' + (files.length > 1 ? 's' : '') + ' added'); setTimeout(function () { location.reload(); }, 600); }, function () { toast('Could not save photos in this browser'); });
    });
  };

  Pages.letter = function () {
    var text = fmtRaw(C.letter), sign = fmtRaw(C.sign), box = $('#letter'), signEl = $('#sign'), timer;
    signEl.textContent = sign; box.textContent = text;
    function type() {
      clearInterval(timer); box.textContent = ''; signEl.style.visibility = 'hidden'; box.classList.add('caret'); var i = 0;
      timer = setInterval(function () { i += 2; box.textContent = text.slice(0, i); if (i >= text.length) { clearInterval(timer); box.classList.remove('caret'); box.textContent = text; signEl.style.visibility = 'visible'; } }, 28);
    }
    $('#replay').addEventListener('click', type);
    $('#seal').addEventListener('click', function (e) { burst(e.clientX, e.clientY, 16); });
  };

  Pages.reasons = function () {
    var rs = C.reasons.split('\n').filter(function (l) { return l.trim(); });
    $('#flips').innerHTML = rs.map(function (r, i) {
      return '<button class="flip" aria-label="Reason ' + (i + 1) + '. Tap to read"><span class="in"><span class="f">' + (i + 1) + '</span><span class="b">' + fmt(r) + '</span></span></button>';
    }).join('');
    $('#flips').addEventListener('click', function (e) { var b = e.target.closest('.flip'); if (b) { b.classList.toggle('on'); if (b.classList.contains('on')) { var r = b.getBoundingClientRect(); burst(r.left + r.width / 2, r.top + r.height / 2, 7); } } });
    var last = -1;
    $('#rand').addEventListener('click', function (e) {
      var n; do { n = Math.floor(Math.random() * rs.length); } while (n === last && rs.length > 1); last = n;
      $('#bigReason').innerHTML = fmt(rs[n]); burst(e.clientX, e.clientY, 12);
    });
    $('#bigReason').innerHTML = fmt(rs[0] || '');
  };

  Pages.music = function () {
    var root = $('#musicRoot');
    function paint() {
      var l = Player.list(), c = Player.cur(), t = l[c] || l[0];
      $('#npTitle').textContent = t.title; $('#npNote').textContent = t.note;
      root.classList.toggle('playing', Player.isPlaying());
      $('#bigPlay').innerHTML = Player.isPlaying() ? '<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M7 5h4v14H7zM13 5h4v14h-4z"/></svg>' : '<svg viewBox="0 0 24 24" fill="currentColor"><path d="M8 5l11 7-11 7z"/></svg>';
      $('#bigPlay').setAttribute('aria-label', Player.isPlaying() ? 'Pause' : 'Play');
      $('#tracks').innerHTML = l.map(function (x, i) { return '<li><button data-i="' + i + '"' + (i === c ? ' aria-current="true"' : '') + '><span><b>' + esc(x.title) + '</b><br><small>' + esc(x.note) + '</small></span><small>' + (i === c && Player.isPlaying() ? 'Playing' : 'Play') + '</small></button></li>'; }).join('');
    }
    function prog() { var a = Player.audio; $('#fill').style.width = (a.duration ? a.currentTime / a.duration * 100 : 0) + '%'; $('#cur').textContent = fmtTime(a.currentTime); $('#dur').textContent = fmtTime(a.duration); }
    Player.on(function () { paint(); prog(); }); paint(); prog();
    $('#bigPlay').onclick = function () { Player.toggle(); }; $('#prev').onclick = Player.prev; $('#nextS').onclick = Player.next;
    $('#tracks').onclick = function (e) { var b = e.target.closest('button'); if (b) Player.pick(+b.getAttribute('data-i')); };
    $('#bar').onclick = function (e) { var r = this.getBoundingClientRect(); Player.seek((e.clientX - r.left) / r.width); };
    Player.audio.addEventListener('loadedmetadata', prog);
  };

  Pages.wishes = function () {
    var ws = LS.get('wishes', []);
    function paint() {
      $('#wishList').innerHTML = ws.length ? ws.map(function (w, i) { return '<li><span>' + esc(w) + '</span><button data-i="' + i + '" aria-label="Remove wish">&times;</button></li>'; }).join('') : '<li><span class="hint">Your wishes will wait here, safe and sound.</span></li>';
    }
    paint();
    $('#wishForm').addEventListener('submit', function (e) {
      e.preventDefault(); var v = $('#wishIn').value.trim(); if (!v) return;
      ws.unshift(v); LS.set('wishes', ws); $('#wishIn').value = ''; paint();
      $('#candle').classList.add('out'); var r = $('#candle').getBoundingClientRect(); burst(r.left + r.width / 2, r.top + 20, 20); toast('Wish made. Blow out the candle with a smile.');
    });
    $('#wishList').addEventListener('click', function (ev) { var b = ev.target.closest('button'); if (b) { ws.splice(+b.getAttribute('data-i'), 1); LS.set('wishes', ws); paint(); } });
    $('#relight').addEventListener('click', function () { $('#candle').classList.remove('out'); });
    $('#candle').addEventListener('click', function () { $('#candle').classList.toggle('out'); });
    $('#promises').innerHTML = PROMISES.map(function (p) { return '<li>' + esc(p) + '</li>'; }).join('');
  };

  Pages.surprise = function () {
    var taps = 0, msgs = ['Tap again', 'Keep going', 'Almost there', 'One more', ''];
    var secret = fmt('I love you more than yesterday, {b}, and less than tomorrow.');
    $('#bigHeart').addEventListener('click', function (e) {
      taps++; burst(e.clientX, e.clientY, 18);
      if (taps >= 5) { $('#secret').textContent = secret; $('#secret').hidden = false; $('#tapHint').hidden = true; for (var i = 0; i < 5; i++) setTimeout(function () { burst(innerWidth * Math.random(), innerHeight * (0.2 + Math.random() * 0.4), 14); }, i * 140); }
      else $('#tapHint').textContent = msgs[taps - 1] || '';
    });
    var used = LS.get('coupons', []);
    function paint() {
      $('#coupons').innerHTML = COUPONS.map(function (c, i) { return '<button class="coupon' + (used.indexOf(i) > -1 ? ' used' : '') + '" data-i="' + i + '"><b>' + c[0] + '</b><small>' + c[1] + '</small></button>'; }).join('');
    }
    paint();
    $('#coupons').addEventListener('click', function (e) {
      var b = e.target.closest('.coupon'); if (!b) return; var i = +b.getAttribute('data-i'), k = used.indexOf(i);
      if (k > -1) used.splice(k, 1); else { used.push(i); burst(e.clientX, e.clientY, 14); toast('Coupon redeemed'); }
      LS.set('coupons', used); paint();
    });
  };

  Pages.qr = function () {
    var base = new URL('.', location.href), mainLink = new URL('index.html', base).href, shortLink = new URL('l/', base).href;
    var S = { shape: 'heart', frame: 'heart', fg: '#8b2a48', bg: '#ffffff', fr: '#f4b6c2', grad: false, g2: '#d4607b' };
    var PRESETS = [['Rose', '#8b2a48', '#f4b6c2', '#d4607b'], ['Midnight', '#2b2140', '#cfc6ea', '#6a3d84'], ['Garden', '#2f5a45', '#cfe5d6', '#6f9a7f'], ['Gold', '#6b4519', '#f2dcb8', '#c79556'], ['Ink', '#1d1d1f', '#f6d6dc', '#8b2a48'], ['Ocean', '#17406b', '#c8e2f4', '#3e86bf']];
    $('#qrUrl').value = LS.get('qrUrl', mainLink);
    $('#linkMain').value = mainLink; $('#linkShort').value = shortLink;
    $('#presets').innerHTML = PRESETS.map(function (p, i) { return '<button class="sw" data-p="' + i + '" style="background:linear-gradient(135deg,' + p[1] + ' 50%,' + p[2] + ' 50%)" aria-label="' + p[0] + ' colours" aria-pressed="' + (i === 0) + '"></button>'; }).join('');
    var cv = document.createElement('canvas');

    function isFinder(r, c, n) { return (r < 7 && c < 7) || (r < 7 && c >= n - 7) || (r >= n - 7 && c < 7); }
    function heartPath(ctx, cx, cy, w, h) {
      var pts = [], minx = 1e9, maxx = -1e9, miny = 1e9, maxy = -1e9, t, x, y;
      for (t = 0; t <= Math.PI * 2 + 0.01; t += 0.02) { x = 16 * Math.pow(Math.sin(t), 3); y = -(13 * Math.cos(t) - 5 * Math.cos(2 * t) - 2 * Math.cos(3 * t) - Math.cos(4 * t)); pts.push([x, y]); minx = Math.min(minx, x); maxx = Math.max(maxx, x); miny = Math.min(miny, y); maxy = Math.max(maxy, y); }
      ctx.beginPath();
      pts.forEach(function (p, i) { var px = cx + (p[0] - (minx + maxx) / 2) / (maxx - minx) * w, py = cy + (p[1] - (miny + maxy) / 2) / (maxy - miny) * h; if (i) ctx.lineTo(px, py); else ctx.moveTo(px, py); });
      ctx.closePath();
    }
    function smallHeart(ctx, cx, cy, s) {
      ctx.beginPath(); ctx.moveTo(cx, cy + s * 0.42);
      ctx.bezierCurveTo(cx - s * 0.95, cy - s * 0.05, cx - s * 0.5, cy - s * 0.62, cx, cy - s * 0.2);
      ctx.bezierCurveTo(cx + s * 0.5, cy - s * 0.62, cx + s * 0.95, cy - s * 0.05, cx, cy + s * 0.42); ctx.closePath(); ctx.fill();
    }
    function rr(ctx, x, y, w, h, r) { ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath(); }

    function draw() {
      var text = $('#qrUrl').value.trim() || mainLink, qr;
      try { qr = new QRLib.QRCode(0, QRLib.ECL.H); qr.addData(text); qr.make(); } catch (e) { toast('That text is too long for a QR code'); return; }
      var n = qr.moduleCount, W = 1000, H = S.frame === 'heart' ? 920 : 1000; cv.width = W; cv.height = H;
      var ctx = cv.getContext('2d'); ctx.clearRect(0, 0, W, H);
      var qs, qx, qy, pad = 0;
      if (S.frame === 'heart') {
        ctx.fillStyle = S.fr; heartPath(ctx, W / 2, H / 2, W * 0.96, H * 0.92); ctx.fill();
        ctx.lineWidth = 10; ctx.strokeStyle = S.fg; ctx.globalAlpha = 0.25; ctx.stroke(); ctx.globalAlpha = 1;
        var card = W * 0.44; qs = card; qx = (W - card) / 2; qy = H * 0.38 - card / 2;
        ctx.fillStyle = S.bg; rr(ctx, qx - 22, qy - 22, card + 44, card + 44, 28); ctx.fill();
      } else if (S.frame === 'square') {
        ctx.fillStyle = S.fr; rr(ctx, 0, 0, W, H, 70); ctx.fill();
        qs = W * 0.74; qx = (W - qs) / 2; qy = (H - qs) / 2; ctx.fillStyle = S.bg; rr(ctx, qx - 30, qy - 30, qs + 60, qs + 60, 36); ctx.fill();
      } else { ctx.fillStyle = S.bg; ctx.fillRect(0, 0, W, H); qs = W * 0.86; qx = (W - qs) / 2; qy = (H - qs) / 2; }
      var m = qs / n, fill = S.fg;
      if (S.grad) { var g = ctx.createLinearGradient(qx, qy, qx + qs, qy + qs); g.addColorStop(0, S.fg); g.addColorStop(1, S.g2); fill = g; }
      ctx.fillStyle = fill;
      for (var r = 0; r < n; r++) for (var c = 0; c < n; c++) {
        if (!qr.isDark(r, c)) continue; var x = qx + c * m, y = qy + r * m;
        if (isFinder(r, c, n) || S.shape === 'square') ctx.fillRect(x - 0.4, y - 0.4, m + 0.8, m + 0.8);
        else if (S.shape === 'dot') { ctx.beginPath(); ctx.arc(x + m / 2, y + m / 2, m * 0.5, 0, 7); ctx.fill(); }
        else smallHeart(ctx, x + m / 2, y + m / 2 + m * 0.04, m * 1.28);
      }
      if (S.frame === 'heart') { ctx.fillStyle = S.fg; ctx.font = '56px "Great Vibes", cursive'; ctx.textAlign = 'center'; ctx.fillText('Happy Anniversary', W / 2, H * 0.70); }
      $('#qrImg').src = cv.toDataURL('image/png');
    }
    function syncSeg() { $$('[data-shape]').forEach(function (b) { b.setAttribute('aria-pressed', b.getAttribute('data-shape') === S.shape); }); $$('[data-frame]').forEach(function (b) { b.setAttribute('aria-pressed', b.getAttribute('data-frame') === S.frame); }); $('#cFg').value = S.fg; $('#cFr').value = S.fr; $('#cBg').value = S.bg; $('#cG2').value = S.g2; $('#gradOn').setAttribute('aria-pressed', S.grad); $('#g2wrap').hidden = !S.grad; }
    document.addEventListener('click', function (e) {
      var s = e.target.closest('[data-shape]'), f = e.target.closest('[data-frame]'), p = e.target.closest('[data-p]');
      if (s) { S.shape = s.getAttribute('data-shape'); }
      if (f) { S.frame = f.getAttribute('data-frame'); }
      if (p) { var q = PRESETS[+p.getAttribute('data-p')]; S.fg = q[1]; S.fr = q[2]; S.g2 = q[3]; $$('[data-p]').forEach(function (b) { b.setAttribute('aria-pressed', b === p); }); }
      if (e.target.closest('#gradOn')) S.grad = !S.grad;
      if (s || f || p || e.target.closest('#gradOn')) { syncSeg(); draw(); }
    });
    [['cFg', 'fg'], ['cFr', 'fr'], ['cBg', 'bg'], ['cG2', 'g2']].forEach(function (k) { $('#' + k[0]).addEventListener('input', function () { S[k[1]] = this.value; draw(); }); });
    $('#qrUrl').addEventListener('input', function () { LS.set('qrUrl', this.value); draw(); });
    $('#useMain').onclick = function () { $('#qrUrl').value = mainLink; LS.set('qrUrl', mainLink); draw(); };
    $('#useShort').onclick = function () { $('#qrUrl').value = shortLink; LS.set('qrUrl', shortLink); draw(); };
    $('#copyMain').onclick = function () { copy($('#linkMain').value, $('#linkMain')); }; $('#copyShort').onclick = function () { copy($('#linkShort').value, $('#linkShort')); };
    $('#saveQr').onclick = function () {
      try { var a = document.createElement('a'); a.download = 'anniversary-qr.png'; a.href = cv.toDataURL('image/png'); document.body.appendChild(a); a.click(); a.remove(); } catch (e) {}
      toast('If nothing downloads, press and hold the picture to save it');
    };
    syncSeg();
    if (document.fonts && document.fonts.load) document.fonts.load('56px "Great Vibes"').then(draw, draw); else draw();
    draw();
  };

  Pages.customize = function () {
    var cur = LS.get('cfg', {});
    ['a', 'b', 'date', 'sign', 'story', 'timeline', 'letter', 'reasons'].forEach(function (k) { $('#f_' + k).value = C[k]; });
    $('#save').addEventListener('click', function () {
      var o = Object.assign({}, LS.get('cfg', {}));
      ['a', 'b', 'date', 'sign', 'story', 'timeline', 'letter', 'reasons'].forEach(function (k) { o[k] = $('#f_' + k).value; });
      LS.set('cfg', o); toast('Saved. Your pages now use these words.'); setTimeout(function () { location.reload(); }, 700);
    });
    $('#reset').addEventListener('click', function () { if (!this.getAttribute('data-sure')) { this.setAttribute('data-sure', '1'); this.textContent = 'Tap again to reset everything'; return; } LS.set('cfg', {}); location.reload(); });
    function list(kind, ul, empty) {
      IDB.all(kind).then(function (items) {
        $(ul).innerHTML = items.length ? items.map(function (it) { return '<li><span>' + esc(it.name) + '</span><button class="btn ghost small" data-id="' + it.id + '">Remove</button></li>'; }).join('') : '<li><span class="hint">' + empty + '</span></li>';
      });
    }
    function wire(input, kind, ul, empty) {
      list(kind, ul, empty);
      $(input).addEventListener('change', function (e) {
        var files = Array.prototype.slice.call(e.target.files || []);
        Promise.all(files.map(function (f) { return IDB.add({ kind: kind, name: f.name.replace(/\.[^.]+$/, ''), blob: f }); })).then(function () { toast('Added'); list(kind, ul, empty); }, function () { toast('Could not save files in this browser'); });
      });
      $(ul).addEventListener('click', function (e) { var b = e.target.closest('button'); if (b) IDB.del(+b.getAttribute('data-id')).then(function () { list(kind, ul, empty); }); });
    }
    wire('#upPhotos', 'photo', '#photoList', 'No photos yet. They appear first in the Gallery.');
    wire('#upSongs', 'song', '#songList', 'No songs yet. They join the playlist.');
  };

  /* ---------- boot ---------- */
  function boot() {
    if (!main) return;
    buildShell(); fillBasics();
    Player.init().then(function () { buildMini(); if (Pages[pageKey]) Pages[pageKey](); }, function () { buildMini(); if (Pages[pageKey]) Pages[pageKey](); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
